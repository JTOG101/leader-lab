# The Leader Lab
Retail leadership workshop site — static version for GitHub Pages.

**Live URL:** https://YOUR-USERNAME.github.io/leader-lab/

## Setup
1. Replace `YOUR-USERNAME` in `robots.txt` and `sitemap.xml`.
2. Replace `YOUR_FORM_ID` in `contact.html` (Formspree).
3. (Optional) Add GA4 ID in `index.html` and uncomment the snippet.
4. Push to `main`, enable GitHub Pages: Settings → Pages → Deploy from a branch.
